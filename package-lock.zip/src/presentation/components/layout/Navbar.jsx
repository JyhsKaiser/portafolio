export const Navbar = () => {
    return (
        <header className="fixed top-0 w-full z-50 bg-base/80 backdrop-blur-md border-b border-zinc-800/50 transition-all duration-300">
            <div className="max-w-6xl mx-auto px-6 h-20 flex items-center justify-between">
                {/* Logo / Nombre */}
                <div className="text-xl font-bold font-mono tracking-tighter text-white">
                    <a href="#" className="hover:text-accent transition-colors">
                        Jovani<span className="text-accent">.dev</span>
                    </a>
                </div>

                {/* Enlaces de navegación */}
                <nav className="hidden md:flex gap-8 text-sm font-medium text-zinc-400">
                    <a href="#projects" className="hover:text-accent transition-colors">Proyectos</a>
                    <a href="#experience" className="hover:text-accent transition-colors">Experiencia</a>
                    <a href="#contact" className="hover:text-accent transition-colors">Contacto</a>
                </nav>

                {/* Botón CTA móvil/desktop */}
                <div>
                    <a
                        href="#contact"
                        className="px-4 py-2 text-sm font-bold text-accent border border-accent/50 rounded-lg hover:bg-accent/10 transition-colors"
                    >
                        Hablemos
                    </a>
                </div>
            </div>
        </header>
    );
};